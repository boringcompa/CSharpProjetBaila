﻿using projet_sadou.entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet_sadou
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
       
        private void Ajouter_Click(object sender, EventArgs e)
        {
            
            
        }
        
        private void Article_Click(object sender, EventArgs e)
        {
            
            
        }
        Articleform articleform;
        private void AjoutArtcl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            articleform = new Articleform();
            articleform.Show();
            this.Hide();
        }

        FormCommande formCommande;
        private void AjouterCmnd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            formCommande = new FormCommande();
            formCommande.Show();
        }
    }
}
