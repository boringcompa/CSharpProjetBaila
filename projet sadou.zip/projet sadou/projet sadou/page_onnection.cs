﻿using projet_sadou.entity;
using projet_sadou.services;
using projet_sadou.models;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms;

namespace projet_sadou
{
    public partial class page_onnection : Form
    {
        private servicesCommandeEntity service = new servicesCommandeEntity();
        
        public page_onnection()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        Menu menu;

        private void button1_Click(object sender, EventArgs e)
        {
            entity.User user = service.SeConnecter(loginBox.Text.Trim(), passwordBox.Text.Trim());
            if (user == null)
            {
               labeler.Visible = true;
            }
            else
            {

                menu = new Menu();
                menu.Show();
                this.Hide();

            }
        }
        Form1 form1;

        private void button2_Click(object sender, EventArgs e)
        {
            form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void page_onnection_Load(object sender, EventArgs e)
        {

        }
    }
}
