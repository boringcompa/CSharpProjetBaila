﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using projet_sadou.entity;


namespace projet_sadou.services
{
    internal class servicesCommandeEntity : iService
    {
        ModelCommande dao = new ModelCommande();

        public servicesCommandeEntity()
        {

        }

        public bool AddArticle(Article article)
        {
            dao.Article.Add(article);
            return dao.SaveChanges() != 0;

        }

        public void AddArticleInCommande(Article article)
        {
            dao.Article.Add(article);
            dao.SaveChanges();
        }

        public void AddClientInCommande(Client client)
        {
            dao.Client.Add(client);
            dao.SaveChanges();
        }

        public bool AddCommande(Commande commande)
        {
            dao.Commande.Add(commande);
            return dao.SaveChanges() != 0;
        }

        public bool AddUser(User user)
        {
            dao.User.Add(user);
            return dao.SaveChanges() != 0;

        }

        public List<Article> ListerArticlesDUnecommande(Commande commande)
        {
            List<Article> articles = dao.Article.ToList().Where(article => article.Id == commande.article_id).ToList();
            commande.QteCommande = articles.Sum(article => article.Stock);
            return articles;
        }

        public List<Commande> ListerCommandeD(DataGridView dataGridView1)
        {
            return dao.Commande.ToList();
        }

        public List<User> ListerUser()
        {
            return dao.User.ToList();
        }

        public User SeConnecter(string Login, string Password)
        {
            return dao.User.ToList().Where(
                                  u => u.Login1.Trim().CompareTo(Login) == 0 &&
                                  u.Password1.Trim().CompareTo(Password) == 0

                         ).FirstOrDefault();
        }

        public bool AddCommandeD(Commande commande)
        {
            dao.Commande.Add(commande);
            return dao.SaveChanges() != 0;
        }

        public void listerUser(DataGridView listUsers)
        {
            listUsers.DataSource = dao.User.ToList();
        }


       

        public List<Article> ListerArticle()
        {
            return dao.Article.ToList();
        }

        public void listerArt(DataGridView dgvArticle)
        {
            dgvArticle.DataSource = dao.Article.ToList();
        }

        public List<Commande> ListerCommande()
        {
            throw new NotImplementedException();
        }
    }
}
