﻿using projet_sadou.entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_sadou.services
{
    interface iService
    {
        bool AddUser(User user);
        List<User> ListerUser();
        bool AddCommande(Commande commande);
        List<Commande> ListerCommande();
        bool AddArticle(Article article);
        List<Article> ListerArticle();
        void AddClientInCommande(Client client);
        void AddArticleInCommande(Article article);
        List<Article> ListerArticlesDUnecommande(Commande commande);
        
    }
}
