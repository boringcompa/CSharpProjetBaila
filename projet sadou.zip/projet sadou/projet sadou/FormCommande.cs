﻿using projet_sadou.entity;
using projet_sadou.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet_sadou
{
    public partial class FormCommande : Form
    {
        private servicesCommandeEntity service = new servicesCommandeEntity();

        public FormCommande()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            service.ListerCommandeD(dataGridView1);

        }

        public void ClearControl()
        {
            foreach (var control in groupBox1.Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Clear();
                }

            }
        }



            private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Enregistrer_Client_Click(object sender, EventArgs e)
        {
            Client client = new Client()
            {

              Nom1=maskedTextboxNom.Text,
              Prenom1=maskedTextBoxPrenom.Text,
              Telephone1=maskedTextBoxTelephone.Text,
              Adresse1=maskedTextBoxTelephone.Text,
            };

            service.AddClientInCommande(client);
           // service.ListerCommandeD(dataGridView1);
            //-------------------
            ClearControl();
        }

        private void ADD1_Click(object sender, EventArgs e)
        {

            Commande commande = new Commande()
            {

                NumCommande = float.Parse(numcom.Text),
                DateCommande = dateTimePicker1.Value,
            };

            service.AddCommandeD(commande);
            
            //-------------------
            ClearControl();
        }

        private void Search1_Click(object sender, EventArgs e)
        {
            
        }

        private void FormCommande_Load(object sender, EventArgs e)
        {

        }
    }
}
