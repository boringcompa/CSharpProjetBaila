﻿namespace projet_sadou
{
    partial class page_onnection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginBox = new System.Windows.Forms.TextBox();
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.buttonconnexion = new System.Windows.Forms.Button();
            this.inscription = new System.Windows.Forms.Button();
            this.labeler = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.labelerror = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // loginBox
            // 
            this.loginBox.Location = new System.Drawing.Point(253, 134);
            this.loginBox.Name = "loginBox";
            this.loginBox.Size = new System.Drawing.Size(259, 20);
            this.loginBox.TabIndex = 0;
            this.loginBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // passwordBox
            // 
            this.passwordBox.Location = new System.Drawing.Point(253, 196);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.Size = new System.Drawing.Size(259, 20);
            this.passwordBox.TabIndex = 1;
            this.passwordBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(253, 256);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(77, 17);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Remember";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // buttonconnexion
            // 
            this.buttonconnexion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.buttonconnexion.Location = new System.Drawing.Point(424, 248);
            this.buttonconnexion.Name = "buttonconnexion";
            this.buttonconnexion.Size = new System.Drawing.Size(88, 30);
            this.buttonconnexion.TabIndex = 3;
            this.buttonconnexion.Text = "Se connecter";
            this.buttonconnexion.UseVisualStyleBackColor = false;
            this.buttonconnexion.Click += new System.EventHandler(this.button1_Click);
            // 
            // inscription
            // 
            this.inscription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(25)))), ((int)(((byte)(40)))));
            this.inscription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.inscription.Location = new System.Drawing.Point(630, 28);
            this.inscription.Name = "inscription";
            this.inscription.Size = new System.Drawing.Size(113, 31);
            this.inscription.TabIndex = 4;
            this.inscription.Text = "S\'inscrire";
            this.inscription.UseVisualStyleBackColor = false;
            this.inscription.Click += new System.EventHandler(this.button2_Click);
            // 
            // labeler
            // 
            this.labeler.AutoSize = true;
            this.labeler.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeler.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.labeler.Location = new System.Drawing.Point(296, 69);
            this.labeler.Name = "labeler";
            this.labeler.Size = new System.Drawing.Size(178, 22);
            this.labeler.TabIndex = 5;
            this.labeler.Text = "Gestion Commercial";
            this.labeler.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.linkLabel1.Location = new System.Drawing.Point(250, 317);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(103, 14);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Mot de Passe oublié?";
            // 
            // labelerror
            // 
            this.labelerror.AutoSize = true;
            this.labelerror.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelerror.ForeColor = System.Drawing.Color.Crimson;
            this.labelerror.Location = new System.Drawing.Point(249, 356);
            this.labelerror.Name = "labelerror";
            this.labelerror.Size = new System.Drawing.Size(297, 24);
            this.labelerror.TabIndex = 7;
            this.labelerror.Text = "Login ou Mot de passe Incorrect";
            this.labelerror.Visible = false;
            // 
            // page_onnection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(71)))));
            this.ClientSize = new System.Drawing.Size(755, 412);
            this.Controls.Add(this.labelerror);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.labeler);
            this.Controls.Add(this.inscription);
            this.Controls.Add(this.buttonconnexion);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.passwordBox);
            this.Controls.Add(this.loginBox);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.Name = "page_onnection";
            this.Text = "page_onnection";
            this.Load += new System.EventHandler(this.page_onnection_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox loginBox;
        private System.Windows.Forms.TextBox passwordBox;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button buttonconnexion;
        private System.Windows.Forms.Button inscription;
        private System.Windows.Forms.Label labeler;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label labelerror;
    }
}